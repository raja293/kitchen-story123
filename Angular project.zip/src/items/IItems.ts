
export interface IItems {

    //properties
    itemid: number,
    itemName: string,
    itemcat: string,
    itemRating: number,
    itemImg: string,
    itemprice:number,
    itemquantity:number,
    totalprice:number
}